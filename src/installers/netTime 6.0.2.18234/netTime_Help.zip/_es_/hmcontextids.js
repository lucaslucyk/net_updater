﻿var hmContextIds = new Array();
function hmGetContextId(query) {
    var urlParams;
    var match,
        pl = /\+/g,
        search = /([^&=]+)=?([^&]*)/g,
        decode = function (s) { return decodeURIComponent(s.replace(pl, " ")); },
    params = {};
    while (match = search.exec(query))
       params[decode(match[1])] = decode(match[2]);
    if (params["contextid"]) return decodeURIComponent(hmContextIds[params["contextid"]]);
    else return "";
}

hmContextIds["134"]="int_.htm";
hmContextIds["133"]="inst_.htm";
hmContextIds["170"]="iniciar-nettime5.htm";
hmContextIds["184"]="activar-y-acceder-a-nettime5.htm";
hmContextIds["185"]="desactivar-y-reinstalar-nettim.htm";
hmContextIds["183"]="proc_.htm";
hmContextIds["147"]="form_.htm";
hmContextIds["107"]="modulo_horario.htm";
hmContextIds["132"]="inc_.htm";
hmContextIds["159"]="inc_comportamiento_de_las_incidenc.htm";
hmContextIds["167"]="inc_productivas_en_el_centro.htm";
hmContextIds["168"]="inc_productivas_fuera_del_centro.htm";
hmContextIds["165"]="inc_otras_actividades_en_el_centro.htm";
hmContextIds["166"]="inc_otras_actividades_fuera_del_ce.htm";
hmContextIds["158"]="inc_ausencias_justificadas.htm";
hmContextIds["162"]="inc_incidencias_arrastrables.htm";
hmContextIds["164"]="inc_jerarquia_de_las_incidencias.htm";
hmContextIds["163"]="inc_incidencias_predefinidas.htm";
hmContextIds["161"]="inc_elementos_de_la_definicion_de_.htm";
hmContextIds["160"]="inc_creacion_de_una_incidencia.htm";
